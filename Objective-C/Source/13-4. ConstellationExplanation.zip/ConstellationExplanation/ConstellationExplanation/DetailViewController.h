//
//  DetailViewController.h
//  ConstellationExplanation
//
//  Created by ChoiJinYoung on 3/6/16.
//  Copyright © 2016 appstamp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController
- (IBAction)backButtonAction:(id)sender;

@end
